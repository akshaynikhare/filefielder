/*
 * jQuery File Upload Plugin JS Example
 * https://github.com/blueimp/jQuery-File-Upload
 *
 * Copyright 2010, Sebastian Tschan
 * https://blueimp.net
 *
 * Licensed under the MIT license:
 * http://www.opensource.org/licenses/MIT
 */

/* global $, window */
$mode ='P';
$days='0';
$hours='0';
$min='0';

$(function () {

    'use strict';
    $('#fileupload').fileupload({
        url: 'UploadHandler.php',
        maxFileSize: 999999999, //1gb
        maxChunkSize: 10000000, // 10 MB
        maxNumberOfFiles:1,
        done: function (e,data) {
           $.each(data.files,function (index,file) {
               jQuery.ajax({
                       type:"POST",
                       url:'phphome1.php',
                       dataType: 'json',
                       data: {functionname:'uplink',pname: file.name,mode: $mode ,days: $days,hours: $hours,min: $min,size:file.size},
                       success: function (obj,textstatus) {
                           if(!('error' in obj)){
                               alert(obj.result);
                           }else {
                               alert(obj.result);
                           }
                       }
                   });

               });

            window.location.href = "home.php";

        },
        add: function (e, data) {
            if (e.isDefaultPrevented()) {
                return false;
            }

            var $this = $(this),
                that = $this.data('blueimp-fileupload') ||
                    $this.data('fileupload'),
                options = that.options;
            data.context = that._renderUpload(data.files)
                .data('data', data)
                .addClass('processing');
            options.filesContainer[
                options.prependFiles ? 'prepend' : 'append'
                ](data.context);
            that._forceReflow(data.context);
            that._transition(data.context);
            data.process(function () {
                return $this.fileupload('process', data);
            }).always(function () {
                data.context.each(function (index) {
                    $(this).find('.size').text(
                        that._formatFileSize(data.files[index].size)
                    );
                }).removeClass('processing');
                that._renderPreviews(data);
            }).done(function () {
                data.context.find('.start').prop('disabled', false);
                data.context.find('.days1').prop('value', $days);
                data.context.find('.hours1').prop('value',$hours);
                data.context.find('.min1').prop('value', $min);
                data.context.find('.mode1').prop('value', $mode);
                if($mode==='T')
                data.context.find('.xtime').append("file will expire in "+$days+" days "+$hours+" hours "+$min+" min ");
                else
                data.context.find('.xtime').append("file will not expire");

                if ((that._trigger('added', e, data) !== false) &&
                    (options.autoUpload || data.autoUpload) &&
                    data.autoUpload !== false) {
                    data.submit();
                }
            }).fail(function () {
                if (data.files.error) {
                    data.context.each(function (index) {
                        var error = data.files[index].error;
                        if (error) {
                            $(this).find('.error').text(error);
                        }
                    });
                }
            });
        }

    });
    // Enable iframe cross-domain access via redirect option:
    $('#fileupload').fileupload(
        'option'
    );


});



function storageT() {
    if(document.getElementById("Temprory"))
    {
        document.getElementById("permanent").checked=false;
        document.getElementById("day").disabled=false;
        document.getElementById("hour").disabled=false;
        document.getElementById("mi").disabled=false;
        $mode='T';
        $days= document.getElementById("day").value;
        $hours=document.getElementById("hour").value;
        $min=document.getElementById("mi").value;
    }
}

function storageP() {
    if(document.getElementById("permanent"))
    {

        document.getElementById("day").disabled=true;
        document.getElementById("hour").disabled=true;
        document.getElementById("mi").disabled=true;

        document.getElementById("Temprory").checked=false;
        $mode='P';
        $days=0;
        $hours=0;
        $min=0;
    }
}

function tupdate(){
    $days= document.getElementById("day").value;
    $hours=document.getElementById("hour").value;
    $min=document.getElementById("mi").value;

}
