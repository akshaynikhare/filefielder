<?php
/**
 * Created by PhpStorm.
 * User: hideout
 * Date: 2/23/2017
 * Time: 3:33 PM
 */

require "download.php";
$n=$_REQUEST['fn'];
//$n="1.jpg";
output_file("out_t/".$n,$n);

//cleaning outbound temprery
/*$files = glob('out_t/*.*');
foreach($files as $file) {
    if (is_file($file))
        if (unlink($file) == false)
            echo "<br> unable to deleat -> " . $file;//deleat file
}
*/