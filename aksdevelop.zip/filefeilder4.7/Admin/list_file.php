<?php
require "../dbcon.php";
session_start(); 

$conn = dbcon("ecloud");
$result = mysqli_query($conn,"SELECT * FROM fkeys , file, users WHERE (( fkeys.uname = file.uname) AND (file.user_id=users.id))");



?>
<html>
<head>
<title>file List</title>
<link rel="stylesheet" type="text/css" href="styles.css" />
<script language="javascript" src="users.js" type="text/javascript"></script>
</head>
<body>
<form name="frmfile" method="post" action="">
<div style="width:500px;">
<table border="0" cellpadding="10" cellspacing="1" width="500" class="tblListForm">
<tr class="listheader">
<td>file name</td>
    <td>size</td>
    <td>mode</td>
<td>key</td>
<td>email</td>
    <td>submit date</td>
    <td>submit time</td>
    <td>expiry date</td>
    <td>expiry time</td>
</tr>
<?php
$i=0;
while($row = mysqli_fetch_array($result)) {
	if($i%2==0)
$classname="evenRow";
else
$classname="oddRow";

?>
<tr class="<?php if(isset($classname)) echo $classname;?>">
<td><?php echo $row["fname"]; ?></td>
    <td><?php echo $row["size"]; ?></td>
    <td><?php echo $row["mode"]; ?></td>
<td><?php echo $row["keyx"]; ?></td>
<td><?php echo $row["email"]; ?></td>
    <td><?php echo $row["date"]; ?></td>
    <td><?php echo $row["time"]; ?></td>
    <td><?php echo $row["exp_date"]; ?></td>
    <td><?php echo $row["exp_time"]; ?></td>
</tr>
<?php
$i++;
}
?>

</table>
</form>
</div>




</body></html>