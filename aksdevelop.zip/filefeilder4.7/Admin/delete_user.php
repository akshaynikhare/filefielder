<?php
require "../dbcon.php";
$conn = dbcon("ecloud");
$rowCount = count($_POST["users"]);
for($i=0;$i<$rowCount;$i++) {
    $query = mysqli_query("DELETE FROM users WHERE id='" . $_POST["users"][$i] . "'");
}
header("Location:list_user.php");
?>s