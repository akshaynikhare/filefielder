<?php
require "../dbcon.php";
$conn = dbcon("ecloud");
session_start();



if(isset($_POST["submit"]) && $_POST["submit"]!="") {
$usersCount = count($_POST["name"]);
for($i=0;$i<$usersCount;$i++) {
mysqli_query($conn,"UPDATE users set name='" . $_POST["name"][$i] . "', username='" . $_POST["username"][$i] . "', email='" . $_POST["email"][$i] . "', ph='" . $_POST["ph"][$i] . "', status='" . $_POST["status"][$i] . "' WHERE id='" . $_POST["id"][$i] . "'");
}
header("Location:list_user.php");
}
?>
<html>
<head>
<title>Edit Multiple User</title>
<link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body>
<form name="frmUser" method="post" action="">
<div style="width:500px;">
<table border="0" cellpadding="10" cellspacing="0" width="500" align="center">
<tr class="tableheader">
<td>Edit User</td>
</tr>
<?php
$rowCount = count($_POST["users"]);
for($i=0;$i<$rowCount;$i++) {
$result = mysqli_query($conn,"SELECT * FROM users WHERE id='" . $_POST["users"][$i] . "'");
$row[$i]= mysqli_fetch_array($result);
?>
<tr>
<td>
<table border="0" cellpadding="10" cellspacing="0" width="500" align="center" class="tblSaveForm">
<tr>
<td><label>name</label></td>
<td><input type="hidden" name="id[]" class="txtField" value="<?php echo $row[$i]['id']; ?>"><input type="text" name="name[]" class="txtField" value="<?php echo $row[$i]['name']; ?>"></td>
</tr>
<tr>
<td><label>username</label></td>
<td><input type="text" name="username[]" class="txtField" value="<?php echo $row[$i]['username']; ?>"></td>
</tr>
<td><label>Email ID</label></td>
<td><input type="text" name="email[]" class="txtField" value="<?php echo $row[$i]['email']; ?>"></td>
</tr>
<td><label>Phone No.</label></td>
<td><input type="text" name="ph[]" class="txtField" value="<?php echo $row[$i]['ph']; ?>"></td>
</tr>
<td><label>Active</label></td>
<td>
	<select name="status[]" class="txtField" value="<?php echo $row[$i]['status']; ?>">
		<option value="YES" > YES </option>
		<option value="NO" > NO </option>
	</select>	

</td>
</tr>
</table>
</td>
</tr>
<?php
}
?>
<tr>
<td colspan="2"><input type="submit" name="submit" value="Submit" class="btnSubmit"></td>
</tr>
</table>
</div>
</form>



</td>

</body></html>