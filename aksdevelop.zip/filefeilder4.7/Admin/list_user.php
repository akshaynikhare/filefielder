<?php
require "../dbcon.php";
session_start(); 
$conn = dbcon("ecloud");
$result = mysqli_query($conn,"SELECT * FROM users");
?>
<html>
<head>
<title>Users List</title>
<link rel="stylesheet" type="text/css" href="styles.css" />
<script language="javascript" src="users.js" type="text/javascript"></script>
</head>
<body>
<form name="frmUser" method="post" action="">
<div style="width:500px;">
<table border="0" cellpadding="10" cellspacing="1" width="500" class="tblListForm">
<tr class="listheader">
<td></td>
<td>NAme</td>
<td>username</td>

<td>email</td>
<td>ph</td>
<td>status</td>
</tr>
<?php
$i=0;
while($row = mysqli_fetch_array($result)) {
	if($i%2==0)
$classname="evenRow";
else
$classname="oddRow";

?>
<tr class="<?php if(isset($classname)) echo $classname;?>">
<td><input type="checkbox" name="users[]" value="<?php echo $row["id"]; ?>" ></td>
<td><?php echo $row["name"]; ?></td>
<td><?php echo $row["username"]; ?></td>
<td><?php echo $row["email"]; ?></td>
<td><?php echo $row["ph"]; ?></td>
<td><?php echo $row["status"]; ?></td>
</tr>
<?php
$i++;
}
?>
<tr class="listheader">
<td colspan="4"><input type="button" name="update" value="Update" onClick="setUpdateAction();" /> <input type="button" name="delete" value="Delete"  onClick="setDeleteAction();" /></td>
</tr>
</table>
</form>
</div>




<?php

if(isset($_POST["trankDB"]))
{
    $result = mysqli_query($conn,"TRUNCATE TABLE fkeys");
    if($result!=TRUE)
        echo "<br>error:  ".$result;
    else
    {
        echo "<br>all keys entrys deleated sucessfully";

        $result = mysqli_query($conn,"TRUNCATE TABLE file");
        if($result!=TRUE)
            echo "<br>error:  ".$result;
        else
        {
            echo "<br>all files entrys deleated sucessfully";
            echo "<br> deleating files stored ..";
            $files = glob('../files/*.*');
            foreach($files as $file){
                if(is_file($file))
                    if(unlink($file)==false)
                        echo "<br> unable to deleat -> ".$file;  //deleat file
            }

            echo "<br> deleating inbound tempery folder stored ..";
            $files = glob('../pfiles/*');
            foreach($files as $file){
                if(is_file($file))
                    if(unlink($file)==false)
                        echo "<br> unable to deleat -> ".$file;  //deleat file
            }

            echo "<br> deleating outbound tempery folder stored ..";
            $files = glob('../out_t/*');
            foreach($files as $file){
                if(is_file($file))
                    if(unlink($file)==false)
                        echo "<br> unable to deleat -> ".$file;  //deleat file
            }




        }



    }







}


if(isset($_POST["filelist"]))
{
	header("location:list_file.php");
}



?>


<div>

    <form method="post" action="">
        <br><br><br>this will deleat all files from all user and therir relative keys stored in database.<br><br>
        <input type="submit" value="deleat all files & key" name="trankDB">
    </form>
</div>

<div>

    <form method="post" action="">
            <input type="submit" value="all file list" name="filelist">
    </form>
</div>


</body></html>