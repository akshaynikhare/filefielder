<?php
$con = mysql_connect("localhost","root","");
mysql_select_db("ecloud",$conn);

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

  $sql = "select * from users";
  if ($result=mysqli_query($con,$sql)) {
       if(mysqli_num_rows($result)>0)
       {

        echo "<table border=1 >";
        echo "<tr>";
        echo "<th>id</th>";
        echo "<th>name</th>";
        echo "<th>Username</th>";
        echo "<th>Email</th>";
        echo "<th>Phone</th>";
        echo "<th>status</th>";
        echo "</tr>";
        while($row=mysqli_fetch_array($result))
        {

        echo "<tr>";
        echo "<td>".$row['user id']."</td>";
        echo "<td>".$row['name']."</td>";
        echo "<td>".$row['username']."</td>";
        echo "<td>".$row['email']."</td>";
        echo "<td>".$row['ph']."</td>";
        echo "<td>".$row['status']."</td>";
        echo "</tr>";
        }   
        echo "</table>" ;
        mysqli_free_result($result);

       }


  }
?>