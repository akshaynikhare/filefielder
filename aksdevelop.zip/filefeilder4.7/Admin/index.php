<?php session_start();
require "../dbcon.php";
if (isset($_POST['login']))
{
    $con=dbcon("ecloud");
    $email = mysqli_real_escape_string($con, $_POST['inputEmail']);
    $password = mysqli_real_escape_string($con, $_POST['inputPassword']);
    $query    = mysqli_query($con, "SELECT * FROM admin WHERE  password='$password' and email='$email'");
    $row    = mysqli_fetch_array($query);
    $num_row  = mysqli_num_rows($query);
    if ($num_row > 0)
    {header('location:list_user.php');}
    else
    {
        echo 'Invalid Email and Password Combination';
    }
}



?>

        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="utf-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <meta name="description" content="">
            <meta name="author" content="">
            <link rel="icon" href="../../favicon.ico">

         <title>Admin pannel - Signin</title>


        <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="../css/signin.css" rel="stylesheet">



    </head>

    <body>

    <div class="container">

        <form class="form-signin" method="post" action="">
            <h2 class="form-signin-heading">Please sign in</h2>
            <label for="inputEmail" class="sr-only">Username</label>
            <input type="text" name="inputEmail" id="inputEmail"  class="form-control" placeholder="Username" required autofocus>
            <label for="inputPassword" class="sr-only">Password</label>
            <input type="password" name="inputPassword" id="inputPassword" class="form-control" placeholder="Password" required>
            <div class="checkbox">
                <label>
                    <input type="checkbox" value="remember-me"> Remember me
                </label>
            </div>
            <button class="btn btn-lg btn-primary btn-block" type="submit" name="login" id="login">Sign in</button>
        </form>

    </div>


    </body>
    </html>


